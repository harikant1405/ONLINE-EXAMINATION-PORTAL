<html>
<head>
<title>
</title>
</head>
<body>
    <form action="demo1.php" method="POST">
        To:<input type="text" name="mail_to"><br>
        Subject:To:<input type="text" name="mail_sub"><br/>
        Message:To:<input type="text" name="mail_msg"><br/>
        <input type="submit" name="submit" value="submit">
    </form>
</body>
</html>