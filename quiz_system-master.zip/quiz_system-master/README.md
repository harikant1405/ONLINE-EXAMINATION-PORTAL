# quiz_system
A mini project for taking online exam  , billd in HTML/CSS/BOOTSTRAP/PHP/MYSQL


Hello friend's



Here the online quiz system is availble to use 
the features which are present in this project are as follow:

1. Two types of users admin as well as student(who can give an exam)
2. The admin can conduct the exam of dfferent subject like PHP and MATHS
3. The student can give the  exam 
4. The result is sended over there registered email id
5. Student can give feedback about the exam
6. Admin can check who is registered for the exam
7. the profile facilty is there 


if someone want to use this project he/she have to configure as

for this project there is need for the server like a localhost 
 tool  = xampp,PHPmyadmin,browser 
 
 to execute on local pc
 download the file and paste it into the htdocs folder of the xampp and import the mysql file into phpmyadmin
 and changle the details in the dbh.php file about the dbname,username,password etc.
 to use the mailing features you have to give your mail id and password in the answer.php and answer1.php file 
 
 
Note : for th mailing your 2 way steps verification should be off of Gmail and allow third party app


Here you will found some unnecessary file you can delete it according to your wish..............


if you find any difficulty in the configure u can contact me

Thank You  Guy's!......





