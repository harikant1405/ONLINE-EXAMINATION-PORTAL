<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style=" background-image:url(Laptop.jpg); "> 
  <div class="container" >
    

<div class="container">
      
        <div class="col-sm-12 " style="padding-top: 20px;">
         <a href="#"><img src="logo.png"></a>
              
        </div>
      
  </div>

          <div class="container">
                     <div class="col-sm-12">       
            
                <div class="col-sm-6 " style="color: gray; padding-top: 90px">

                                    <h2 >Welcome to Mother's Education Hub</h2>
                        Access your test series, score performance report, online study materials and recent updates. Get the ultimate simulated experience of the actual test with complete strength and weakness analysis.
           
              </div>
              <div class="col-sm-6" style="padding-left: 45px;">
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h2>Sign up now </h2>
                      <h6> Fill in the form below to get instant access:</h6>                    
                    </div>
                     
                      <div class="panel-body">
                      <form class="signup-form" action="store.php" method="post">
                       <div class="form-group">
                          <label for="name">Name:</label>
                          <input type="name" class="form-control" name="name" placeholder="Enter Name">
                        </div>

                        <div class="form-group">
                          <label for="phno">Phone No:</label>
                          <input type="text" class="form-control" name="phno" placeholder="Enter Mobile No">
                        </div>

                        <div class="form-group"> 
                          <label for="email">Email:</label>
                          <input type="email" class="form-control" name="email" placeholder="Enter email">
                        </div>
                        <div class="form-group">
                          <label for="pwd">Password:</label>
                          <input type="password" class="form-control" name="pwd" placeholder="Enter password">
                        </div>
                         <input type="submit" name="submit" value="Sign Me Up">  
                        <br><br>
                        <a href="index.php">Back To Log in</a>

                      </form>
                  </div>
              </div>
          </div>
         
 
        </div>
      </div>
      </div>


  
  




  
</body>
</html>
