<html>
<head>
<title>admin profile</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<body>
<div class="container">
<div class="row">
<h2>List of data availble of <admin></admin></h2>
<div class="col-md-7 ">
<div class="panel panel-default">
<div class="panel-heading">  <h4 >Admin Profile</h4></div>
<div class="panel-body">
    <div class="col-sm-6">
    <h4 style="color:#00b1b1;">ADMIN</h4></span>
    <span><p><strong><u>Admin</u></strong></p></span>            
    </div>
    <div class="clearfix"></div>
    <hr style="margin:5px 0 5px 0;">

    <div class="col-sm-5 col-xs-6 tital " >Username:</div><div class="col-sm-7 col-xs-6 "><a href="mailto:">admin@gmail.com</a>
</div>
<div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >First Name:</div><div class="col-sm-7 col-xs-6 ">Admin</div>
<div class="clearfix"></div>
<div class="bot-border"></div>



<div class="col-sm-5 col-xs-6 tital " >Last Name:</div><div class="col-sm-7"> Admin</div>
<div class="clearfix"></div>
<div class="bot-border"></div>


<div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Date Of Birth:</div><div class="col-sm-7">DD-MM-YYYY</div>

<div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Place Of Birth:</div><div class="col-sm-7">Birth Place</div>

<div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Nationality:</div><div class="col-sm-7">Indian</div>

<div class="clearfix"></div>
<div class="bot-border"></div>

<div class="col-sm-5 col-xs-6 tital " >Religion:</div><div class="col-sm-7">Hindu</div>
</div>
</div>
</div> 
</div>
    <form action="admin_pannel.php" method="POST">
        <button class="btn-success" name="submit">Back</button>

    </form>
</body>
</html>




